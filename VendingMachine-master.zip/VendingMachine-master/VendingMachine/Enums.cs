﻿namespace VendingMachineProject
{
    public enum MachineProducts
    {
        Cola = 1,
        Chips = 2,
        Candy = 3,
        Other = 4,
    }

    public enum Coin
    {
        Nickels = 1,
        Dimes = 2,
        Quarters = 3,
        Other = 4,
    }
}
